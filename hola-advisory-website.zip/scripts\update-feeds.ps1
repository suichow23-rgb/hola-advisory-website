param(
  [string]$Root = (Resolve-Path "$PSScriptRoot\..").Path,
  [int]$InsightLimit = 6
)

$ErrorActionPreference = "Stop"

$dataDir = Join-Path $Root "website\data"
$configPath = Join-Path $dataDir "source-config.json"
$insightsPath = Join-Path $dataDir "insights.json"
$opportunitiesPath = Join-Path $dataDir "opportunities.json"

$config = Get-Content -Raw -LiteralPath $configPath | ConvertFrom-Json

$businessTerms = @(
  "vietnam",
  "infrastructure",
  "metro",
  "airport",
  "industrial",
  "logistics",
  "fdi",
  "retail",
  "franchise",
  "property",
  "office",
  "sme",
  "singapore",
  "malaysia",
  "investment",
  "manufacturing",
  "consumer",
  "construction"
)

function ConvertTo-Summary {
  param([string]$Text)

  $clean = ($Text -replace "<[^>]+>", " " -replace "\s+", " ").Trim()
  if ($clean.Length -gt 220) {
    return $clean.Substring(0, 217).Trim() + "..."
  }
  return $clean
}

function Test-BusinessRelevant {
  param([string]$Text)

  $lower = $Text.ToLowerInvariant()
  foreach ($term in $businessTerms) {
    if ($lower.Contains($term)) {
      return $true
    }
  }
  return $false
}

$items = New-Object System.Collections.Generic.List[object]

foreach ($source in $config.newsSources) {
  if ([string]::IsNullOrWhiteSpace($source.rss)) {
    continue
  }

  try {
    $feed = Invoke-RestMethod -Uri $source.rss -TimeoutSec 20
    foreach ($entry in $feed.rss.channel.item) {
      $title = [string]$entry.title
      $description = [string]$entry.description
      $combined = "$title $description"

      if (-not (Test-BusinessRelevant $combined)) {
        continue
      }

      $items.Add([pscustomobject]@{
        category = "Vietnam Signal"
        title = $title
        summary = "SME angle: " + (ConvertTo-Summary $description)
        sourceName = [string]$source.name
        url = [string]$entry.link
        publishedAt = [string]$entry.pubDate
      })
    }
  } catch {
    Write-Warning "Could not refresh $($source.name): $($_.Exception.Message)"
  }
}

if ($items.Count -gt 0) {
  $payload = [pscustomobject]@{
    updatedAt = (Get-Date).ToString("o")
    items = @($items | Select-Object -First $InsightLimit)
  }

  $payload | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $insightsPath -Encoding UTF8
}

$opportunityItems = @(
  [pscustomobject]@{
    type = "sale"
    category = "Business For Sale"
    title = "Vietnam public acquisition listings"
    summary = "Automatically refreshed lead source. Use this as a discovery route only; seller claims, financials, ownership, and availability require direct verification."
    location = "Vietnam"
    price = "Varies"
    sourceName = "BusinessesForSale Vietnam"
    url = "https://www.businessesforsale.com/search/businesses-for-sale-in-vietnam"
    verificationStatus = "Public source only"
  },
  [pscustomobject]@{
    type = "sale"
    category = "Business / Investment"
    title = "SMERGERS Vietnam and regional deal flow"
    summary = "Track business sale, investor, funding, and franchise signals. Use as a discovery route and verify directly before presenting to clients."
    location = "Vietnam / Southeast Asia"
    price = "Varies"
    sourceName = "SMERGERS"
    url = "https://www.smergers.com/"
    verificationStatus = "Public source only"
  },
  [pscustomobject]@{
    type = "franchise"
    category = "Franchise"
    title = "Franchise opportunity pipeline"
    summary = "Reserved for franchise leads from public platforms, chambers, brand submissions, and approved partner referrals."
    location = "Vietnam"
    price = "Case by case"
    sourceName = "Hola Advisory"
    url = "#contact"
    verificationStatus = "Curated only"
  },
  [pscustomobject]@{
    type = "property"
    category = "Property / Workspace"
    title = "Starter office and retail search"
    summary = "Workspace, virtual office, private office, and retail location routes for new Vietnam entrants."
    location = "Ho Chi Minh City"
    price = "On request"
    sourceName = "Hola Advisory"
    url = "#workspace"
    verificationStatus = "Owned / partner route"
  }
)

[pscustomobject]@{
  updatedAt = (Get-Date).ToString("o")
  items = $opportunityItems
} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $opportunitiesPath -Encoding UTF8

Write-Host "Updated insights and opportunities JSON."
